package com.example.music_player_test;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class PlaylistStorage {
    private static final String PREFS_NAME = "music_player_prefs";
    private static final String KEY_PLAYLIST = "playlist_data";

    public static void savePlaylist(Context context, List<Song> playlist) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        JSONArray jsonArray = new JSONArray();
        for (Song song : playlist) {
            JSONObject json = new JSONObject();
            try {
                json.put("title", song.getTitle());
                json.put("uri", song.getUri().toString());
                jsonArray.put(json);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        prefs.edit().putString(KEY_PLAYLIST, jsonArray.toString()).apply();
    }

    public static List<Song> loadPlaylist(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String jsonString = prefs.getString(KEY_PLAYLIST, null);
        List<Song> playlist = new ArrayList<>();
        if (jsonString != null) {
            try {
                JSONArray jsonArray = new JSONArray(jsonString);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject json = jsonArray.getJSONObject(i);
                    String title = json.getString("title");
                    String uriString = json.getString("uri");
                    Uri uri = Uri.parse(uriString);
                    playlist.add(new Song(title, uri));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return playlist;
    }

}