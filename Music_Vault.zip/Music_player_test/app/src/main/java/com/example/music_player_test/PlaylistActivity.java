package com.example.music_player_test;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class PlaylistActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        ArrayList<Song> playlist = getIntent().getParcelableArrayListExtra("playlist");

        ArrayList<String> songTitles = new ArrayList<>();
        for (Song song : playlist) {
            songTitles.add(song.getTitle());
        }

        ListView listView = findViewById(R.id.playlistListView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                songTitles
        );
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("selectedPosition", position);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }

}