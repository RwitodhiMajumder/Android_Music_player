package com.example.music_player_test;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private final ArrayList<Song> playlist = new ArrayList<>();
    private MediaPlayer mediaPlayer;
    private int currentSongIndex = 0;

    private TextView currentSongTitle, currentTimeText, totalTimeText;
    private SeekBar seekBar;
    private ImageButton btnPlayPause;
    private ImageView albumArtView;
    private boolean isPlaying = false;

    private final Handler seekHandler = new Handler();
    private final Runnable updateSeekBar = new Runnable() {
        @Override
        public void run() {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                int current = mediaPlayer.getCurrentPosition();
                seekBar.setProgress(current);
                currentTimeText.setText(formatDuration(current));
                seekHandler.postDelayed(this, 500);
            }
        }
    };

    @SuppressLint("WrongConstant")
    private final ActivityResultLauncher<Intent> filePickerLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        final int takeFlags = result.getData().getFlags()
                                & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        getContentResolver().takePersistableUriPermission(uri, takeFlags);

                        String title = getFileName(uri);
                        Song song = new Song(title, uri);
                        playlist.add(song);
                        PlaylistStorage.savePlaylist(this, playlist);
                        updateTitle(title);
                        currentSongIndex = playlist.size() - 1;
                        playCurrentSong();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentSongTitle = findViewById(R.id.currentSongTitle);
        seekBar = findViewById(R.id.seekBar);
        currentTimeText = findViewById(R.id.currentTime);
        totalTimeText = findViewById(R.id.totalTime);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        albumArtView = findViewById(R.id.albumArtView);

        ImageButton btnNext = findViewById(R.id.btnNext);
        ImageButton btnPrev = findViewById(R.id.btnPrev);
        MaterialButton btnSelect = findViewById(R.id.btnSelect);
        Button btnPlaylist = findViewById(R.id.btnPlaylist);

        btnSelect.setOnClickListener(v -> openFilePicker());
        btnPlayPause.setOnClickListener(v -> togglePlayPause());
        btnNext.setOnClickListener(v -> playNextSong());
        btnPrev.setOnClickListener(v -> playPreviousSong());
        btnPlaylist.setOnClickListener(v -> openPlaylistActivity());

        playlist.addAll(PlaylistStorage.loadPlaylist(this));
        if (!playlist.isEmpty()) {
            updateTitle(playlist.get(currentSongIndex).getTitle());
            updateAlbumArt(playlist.get(currentSongIndex).getUri());
        }

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            boolean userTouch = false;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mediaPlayer != null) {
                    currentTimeText.setText(formatDuration(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                userTouch = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mediaPlayer != null && userTouch) {
                    mediaPlayer.seekTo(seekBar.getProgress());
                    userTouch = false;
                }
            }
        });
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        filePickerLauncher.launch(intent);
    }

    private String getFileName(Uri uri) {
        String result = "Unknown";
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index != -1) result = cursor.getString(index);
            }
        }
        return result;
    }

    private void playCurrentSong() {
        if (playlist.isEmpty()) {
            Toast.makeText(this, "No song to play", Toast.LENGTH_SHORT).show();
            return;
        }

        Song song = playlist.get(currentSongIndex);
        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                seekHandler.removeCallbacks(updateSeekBar);
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(this, song.getUri());
            mediaPlayer.prepare();
            mediaPlayer.start();
            isPlaying = true;
            btnPlayPause.setImageResource(R.drawable.ic_pause);
            updateTitle(song.getTitle());
            updateAlbumArt(song.getUri());

            int duration = mediaPlayer.getDuration();
            seekBar.setMax(duration);
            totalTimeText.setText(formatDuration(duration));
            seekHandler.postDelayed(updateSeekBar, 0);

            mediaPlayer.setOnCompletionListener(mp -> {
                isPlaying = false;
                btnPlayPause.setImageResource(R.drawable.ic_play);
                seekHandler.removeCallbacks(updateSeekBar);
            });

        } catch (IOException | SecurityException e) {
            e.printStackTrace();
            Toast.makeText(this, "Unable to play this file", Toast.LENGTH_SHORT).show();
        }
    }

    private void togglePlayPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                btnPlayPause.setImageResource(R.drawable.ic_play);
                seekHandler.removeCallbacks(updateSeekBar);
            } else {
                mediaPlayer.start();
                btnPlayPause.setImageResource(R.drawable.ic_pause);
                seekHandler.postDelayed(updateSeekBar, 0);
            }
            isPlaying = !isPlaying;
        } else {
            playCurrentSong();
        }
    }

    private void playNextSong() {
        if (playlist.isEmpty()) return;
        currentSongIndex = (currentSongIndex + 1) % playlist.size();
        playCurrentSong();
    }

    private void playPreviousSong() {
        if (playlist.isEmpty()) return;
        currentSongIndex = (currentSongIndex - 1 + playlist.size()) % playlist.size();
        playCurrentSong();
    }

    private void updateTitle(String title) {
        currentSongTitle.setText(title != null ? title : "No song selected");
    }

    private void updateAlbumArt(Uri uri) {
        try {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            mmr.setDataSource(this, uri);
            byte[] artBytes = mmr.getEmbeddedPicture();
            if (artBytes != null) {
                Bitmap albumArt = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
                albumArtView.setImageBitmap(albumArt);
            } else {
                albumArtView.setImageResource(R.drawable.default_album_art);
            }
            mmr.release();
        } catch (Exception e) {
            albumArtView.setImageResource(R.drawable.default_album_art);
            e.printStackTrace();
        }
    }

    private void openPlaylistActivity() {
        Intent intent = new Intent(this, PlaylistActivity.class);
        intent.putParcelableArrayListExtra("playlist", playlist);
        startActivityForResult(intent, 101);
    }

    private String formatDuration(int millis) {
        return String.format("%d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis),
                TimeUnit.MILLISECONDS.toSeconds(millis) % 60);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            seekHandler.removeCallbacks(updateSeekBar);
            mediaPlayer.release();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == RESULT_OK && data != null) {
            int index = data.getIntExtra("selectedPosition", -1);
            if (index >= 0 && index < playlist.size()) {
                currentSongIndex = index;
                playCurrentSong();
            }
        }
    }
}
